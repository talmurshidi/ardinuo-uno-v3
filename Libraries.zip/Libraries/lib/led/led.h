void enableLed(int ledNumber);
void lightUpLed(int ledNumber);
void lightDownLed(int ledNumber);